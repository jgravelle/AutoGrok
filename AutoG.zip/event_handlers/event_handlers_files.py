# event_handlers_files.py

from configs.config_local import DEBUG


